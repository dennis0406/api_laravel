<?php $__env->startSection('title', 'create'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container text-center w-75 mt-3">
        <form action="<?php echo e(route('add')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form_group mb-3">
                <input type="text" class="form-control" name="name" placeholder="Nhập tên món ăn...">
            </div>
            <div class="form_group mb-3">
                <select class="form-select" name="category_id" aria-label="Default select example">
                    <option selected>Chọn danh mục món ăn</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            <div class="form_group mb-3">
                <textarea name="desc" cols="30" rows="3" placeholder="Nhập mô tả món ăn" class="form-control"></textarea>
            </div>
            <div class="form_group mb-3">
                <input type="text" class="form-control" name="image" placeholder="Link hình ảnh món ăn...">
            </div>
            <div class="form_group mb-3">
                <input type="number" class="form-control" name="price" placeholder="Nhập giá món ăn...">
            </div>
            <div class="form_group mb-3">
                <button type="submit" class="btn btn-outline-primary">Tạo</button>
                <a href="/" class="btn-outline-drak btn">Quay lại</a>
            </div>
        </form>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\midterm_lr\resources\views/layouts/create.blade.php ENDPATH**/ ?>