<?php $__env->startSection('title', 'detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="card" style="width: 100%;">
            <img src="<?php echo e($product->image); ?>" class="card-img-top" alt="" width="100%">
            <div class="card-body">
                <h5 class="card-title fw-bold"><?php echo e($product->name); ?></h5>
                <p class="card-text"><?php echo e($product->desc); ?></p>
                <p class="card-text price"><?php echo e($product->price); ?></p>
                <a href="buy/<?php echo e($product->id); ?>" class="btn btn-success">Mua ngay</a>
            </div>
        </div>
        <a href="/" class="btn btn-outline-dark mt-2">Quay lại</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\midterm_lr\resources\views/layouts/detail.blade.php ENDPATH**/ ?>