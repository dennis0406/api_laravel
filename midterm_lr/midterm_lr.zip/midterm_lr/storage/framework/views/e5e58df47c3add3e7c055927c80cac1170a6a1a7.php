<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="container w-75 text-center">
    <h1 class="my-3 text-uppercase cate"><?php echo e($cateName1->name); ?></h1>
    <?php $__currentLoopData = $prdCate1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3 record ">
                    <div class="col-3">
                        <img src="<?php echo e($product->image); ?>" width="100%" alt="">
                    </div>
                    <div class="col-6 content">
                        <p class="text-uppercase fw-bold">
                            <a class="name" href="/detail/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
                        </p>
                        <p class="text-muted">
                            <?php echo e($product->desc); ?>

                        </p>
                    </div>
                    <div class="col-3">
                        <p class="text-bold price">
                            <?php echo e($product->price); ?>

                        </p>
                    </div>
                </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h1 class="my-3 text-uppercase cate"><?php echo e($cateName2->name); ?></h1>
    <?php $__currentLoopData = $prdCate2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3 record">
                    <div class="col-3">
                        <img src="<?php echo e($product->image); ?>" width="100%" alt="">
                    </div>
                    <div class="col-6 content">
                        <p class="text-uppercase fw-bold">
                            <a class="name" href="/detail/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
                        </p>
                        <p class="text-muted">
                            <?php echo e($product->desc); ?>

                        </p>
                    </div>
                    <div class="col-3">
                        <p class="text-bold price">
                            <?php echo e($product->price); ?>

                        </p>
                    </div>
                </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h1 class="my-3 text-uppercase cate"><?php echo e($cateName3->name); ?></h1>
    <?php $__currentLoopData = $prdCate3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3 record">
                    <div class="col-3">
                        <img src="<?php echo e($product->image); ?>" width="100%" alt="">
                    </div>
                    <div class="col-6 content">
                        <p class="text-uppercase fw-bold">
                            <a class="name" href="/detail/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
                        </p>
                        <p class="text-muted">
                            <?php echo e($product->desc); ?>

                        </p>
                    </div>
                    <div class="col-3">
                        <p class="text-bold price">
                            <?php echo e($product->price); ?>

                        </p>
                    </div>
                </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\midterm_lr\resources\views/layouts/index.blade.php ENDPATH**/ ?>